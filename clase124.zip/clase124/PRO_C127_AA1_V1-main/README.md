# PRO_C127_AA1_V1
EXTRACCIÓN DE DATOS WEB - 1  
BeautifulSoup. Selenium.  
  
Solución del proyecto.  
  
### Texto en inglés: PRO-C127-Student-Boilerplate-Code
